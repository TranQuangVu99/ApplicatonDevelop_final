The TeRK.dll is a .NET assembly, which contains built of TeRK C# types generated from TeRK ICE definition.

TeRK is Copyright � 2007 Carnegie Mellon University Robotics
http://www.terk.ri.cmu.edu/

ICE is Copyright � 2008 ZeroC, Inc
http://www.zeroc.com/ice.html

The TeRK.dll assembly is built by Andrew Kirillov for AForge.NET project
andrew.kirillov@aforgenet.com


Note: The TeRK.dll requires Ice.dll and Glacier2.dll, which are part of ICE package.